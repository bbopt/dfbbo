The directories Algo_x contain stats files for a series of single objective problems with no general inequality constraints.
One line in a stats file contains the best objective value obtained up to an evaluation number.
The first value is the evaluation number.  
