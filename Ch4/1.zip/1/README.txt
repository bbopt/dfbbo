The directories Algo_x contain history files for various unconstrained problems.
Each line in a history file corresponds to a single evaluation. 
All evaluations performed by an algorithm are included in the order of evaluation.
Each line contains the coordinates of the variable x followed by the value f(x).  
